package net.nori.ai;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import android.graphics.Color;

public class MainActivity extends Activity {
    private LinearLayout root;
    private TextView status;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24,24,24,24);
        root.setBackgroundColor(Color.rgb(243,247,245));
        TextView title = new TextView(this);
        title.setText("NORI AI\nمساعدك القابل للتطوير");
        title.setTextSize(24); title.setGravity(Gravity.CENTER);
        root.addView(title);
        TextView desc = new TextView(this);
        desc.setText("نسخة تأسيسية لإدارة أوامر التطوير والصلاحيات. محرك AI لم يُربط بعد.");
        desc.setTextSize(15); desc.setPadding(0,24,0,24);
        root.addView(desc);
        status = new TextView(this);
        status.setText("الصلاحيات الافتراضية: التعديل مغلق • الإنترنت مغلق • أوامر النظام مغلقة");
        status.setTextSize(14); root.addView(status);
        addToggle("السماح بتعديل ملفات مساحة العمل", false);
        addToggle("السماح بالاتصال بمزود AI", false);
        addToggle("السماح بقراءة ملفات الهاتف", false);
        addToggle("السماح بالكتابة خارج مساحة العمل", false);
        TextView warning = new TextView(this);
        warning.setText("\nملاحظة: هذه المفاتيح واجهة توضيحية حالياً. سنربطها بمدير الصلاحيات الفعلي في مرحلة التكامل. كل تعديل للمشروع سيظل بحاجة إلى موافقتك.");
        warning.setTextSize(13); root.addView(warning);
        setContentView(root);
    }
    private void addToggle(String label, boolean initial) {
        Switch sw = new Switch(this); sw.setText(label); sw.setChecked(initial);
        sw.setPadding(0,12,0,12);
        sw.setOnCheckedChangeListener((button, checked) -> {
            // UI prototype only: toggles do not grant Android or builder permissions yet.
            status.setText("تم تغيير اختيار واجهة الإعدادات. لم تُمنح صلاحية فعلية في هذه النسخة التجريبية.");
        });
        root.addView(sw);
    }
}
