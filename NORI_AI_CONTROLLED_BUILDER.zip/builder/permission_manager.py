import json
from pathlib import Path

class PermissionManager:
    """User-controlled permissions. Sensitive capabilities default to disabled."""
    DEFAULTS = {
        "workspace_read": True,
        "workspace_edit": False,
        "network_api": False,
        "device_files_read": False,
        "device_files_write": False,
        "shell_commands": False,
        "delete_files": False,
        "install_apps": False,
        "publish_or_upload": False,
        "change_permissions": False,
    }

    def __init__(self, config_path="permissions.json"):
        self.path = Path(config_path)
        self.data = {"permissions": self.DEFAULTS.copy(),
                     "require_approval_for_every_change": True}
        if self.path.exists():
            loaded = json.loads(self.path.read_text(encoding="utf-8"))
            self.data["permissions"].update(loaded.get("permissions", {}))
            self.data["require_approval_for_every_change"] = bool(
                loaded.get("require_approval_for_every_change", True)
            )

    def allowed(self, permission):
        return bool(self.data["permissions"].get(permission, False))

    def set_permission(self, permission, enabled):
        if permission not in self.DEFAULTS:
            raise ValueError("Unknown permission")
        # The agent itself must never grant itself new powers.
        # Permission changes must be made by the user through a trusted UI/config edit.
        raise PermissionError("Change permissions through the user-controlled settings only.")

    def summary(self):
        return dict(self.data["permissions"])
