from pathlib import Path
import difflib
import shutil
from datetime import datetime

BLOCKED_PARTS = {".git", ".github", "secrets", "keystore", "backups"}
BLOCKED_NAMES = {".env", ".env.local", "local.properties"}

class SafeWorkspace:
    """Restricts edits to an explicit workspace directory; never executes generated code."""
    def __init__(self, project_root=".", workspace="workspace", backup_root="backups"):
        self.root = Path(project_root).resolve()
        self.workspace = (self.root / workspace).resolve()
        self.backup_root = (self.root / backup_root).resolve()
        self.workspace.mkdir(parents=True, exist_ok=True)

    def _target(self, relative_path):
        target = (self.workspace / relative_path).resolve()
        if self.workspace not in target.parents and target != self.workspace:
            raise ValueError("Path escapes the authorized workspace")
        if any(part in BLOCKED_PARTS for part in target.parts):
            raise ValueError("Blocked path")
        if target.name in BLOCKED_NAMES:
            raise ValueError("Secret/config file is blocked")
        return target

    def preview(self, relative_path, new_content):
        target = self._target(relative_path)
        old = target.read_text(encoding="utf-8") if target.exists() else ""
        diff = difflib.unified_diff(
            old.splitlines(True), new_content.splitlines(True),
            fromfile=f"before/{relative_path}", tofile=f"after/{relative_path}"
        )
        return "".join(diff)

    def apply(self, relative_path, new_content, user_approved=False, edit_permission=False):
        if not edit_permission:
            raise PermissionError("workspace_edit permission is disabled")
        if not user_approved:
            raise PermissionError("Explicit user approval is required")
        target = self._target(relative_path)
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
            backup = self.backup_root / stamp / relative_path
            backup.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(target, backup)
        target.write_text(new_content, encoding="utf-8")
        return str(target)

    def delete(self, relative_path, user_approved=False, delete_permission=False):
        raise PermissionError("Deletion is disabled in this starter; no delete operation is provided.")
